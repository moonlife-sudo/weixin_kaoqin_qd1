Page({
  data: {},

  onShareAppMessage() {
    return {};
  },
  onClick_3() {
    wx.redirectTo({ url: '/packageC/pages/sPersonInfo/sPersonInfo' });
  },
});